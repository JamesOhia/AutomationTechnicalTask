using System;
using Newtonsoft.Json;
using NUnit.Framework.Legacy;
using NUnit.Framework;
using RestSharp;


    class Program
    {
        static void Main(string[] args)
        {
            string url = "https://simple-books-api.glitch.me";
            // Create a RestClient instance with the base URL
            var client = new RestClient(url);

            // Create a RestRequest instance for the "Get Book Details" request
            var request = new RestRequest("/books", Method.Get);

            // Execute the request and get the response
            var response = client.Execute(request);

            // Output the response body to the console
            Console.WriteLine("Response Body:");
            Console.WriteLine(response.Content);
            Console.ReadLine();  //To be able to see the response body

            // Verify status code is 200 OK
            ClassicAssert.AreEqual(200, (int)response.StatusCode, "Status code is not 200");

            // Parse response body as JSON
            var jsonData = JsonConvert.DeserializeObject<List<Book>>(response.Content);

            // Define the expected book details
            var expectedBooks = new List<Book>
                {
                    new Book { Id = 1, Name = "The Russian", Type = "fiction", Available = true },
                    new Book { Id = 2, Name = "Just as I Am", Type = "non-fiction", Available = false },
                    new Book { Id = 3, Name = "The Vanishing Half", Type = "fiction", Available = true },
                    new Book { Id = 4, Name = "The Midnight Library", Type = "fiction", Available = true },
                    new Book { Id = 5, Name = "Untamed", Type = "non-fiction", Available = true },
                    new Book { Id = 6, Name = "Viscount Who Loved Me", Type = "fiction", Available = true }
                };

            // Verify that all expected books are present in the response
            CollectionAssert.AreEquivalent(expectedBooks, jsonData, "Not all expected books are present");

            // Verify that at least two properties of each book are present in the response
            foreach (var book in jsonData)
            {
                ClassicAssert.IsNotNull(book.Id, "Id property is missing");
                ClassicAssert.IsNotNull(book.Name, "Name property is missing");
                ClassicAssert.IsNotNull(book.Type, "Type property is missing");
                ClassicAssert.IsNotNull(book.Available, "Available property is missing");
            }

            Console.WriteLine("All tests passed!");
    }
    }

public class Book
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Type { get; set; }
    public bool Available { get; set; }
}