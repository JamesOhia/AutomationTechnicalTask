using AmazonItemTest.PageObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;


namespace AmazonItemTest.StepDefinitions
{
    [Binding]
    public sealed class AmazonItemSteps
    {
        private IWebDriver driver;
        private readonly AmazonItemPage amazon;
        private readonly string searchItem = "tp-link n450 wifi router";
        private WebDriverWait wait;

        public AmazonItemSteps()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            amazon = new AmazonItemPage(driver);

        }

        [Given(@"I have navigated to the Amazon page")]
        public void GivenIHaveNavigatedToTheAmazonPage()
        {
            amazon.navigateHomePage();

            if (amazon.capchaDisplayed())
            {
                TestContext.Progress.WriteLine("CAPTCHA encountered. Please solve it manually and press Enter to continue...");
                //Wait for Human Intervention to complete the Captcha. Estimated time 12 seconds
                wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
                wait.Until(ExpectedConditions.ElementIsVisible(amazon.amazonPage));//Amazon Main Page is displayed meaning Captcha has finished
            }
        }

        [When(@"I search for the item")]
        public void WhenISearchForTheItem()
        {
            amazon.searchForItem(searchItem);
            amazon.clickItem();
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementIsVisible(amazon.buyingOptionsButton));
            amazon.clickBuyingOption();
            wait.Until(ExpectedConditions.ElementIsVisible(amazon.addCartButton));
        }

        [When(@"corresponding item is added to the cart")]
        public void WhenCorrespondingItemIsAddedToTheCart()
        {
            amazon.clickAddCartButton();
            wait.Until(ExpectedConditions.ElementIsVisible(amazon.itemAdded));
            Assert.True(amazon.itemAddedDisplayed(), "Item hasn't been added");
            amazon.clickCloseItem();
            amazon.clickGoToCartButton();
        }

        [Then(@"I should see the Item and amount in the cart")]
        public void ThenIShouldSeeTheItemAndAmountInTheCart()
        {
            //Assert.True(amazon.capchaDisplayed());
            Assert.True(amazon.correctItemTitleDisplayed(),"Element with xpath is not visible or Invalid Item");
            Assert.True(amazon.correctItemPriceDisplayed(), "Element with xpath is not visible or Invalid Price");
        }


        [AfterScenario]
        public void AfterScenario()
        {
            driver.Quit();
        }

    }
}

