﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace AmazonItemTest.PageObjects
{
    public class AmazonItemPage
    {
        private readonly IWebDriver driver;
        private readonly string baseUrl = "https://www.amazon.com/";
        public By amazonPage = By.XPath("//a[@id='nav-logo-sprites']");
        private By searchBox = By.XPath("//input[@type='text']");
        private By item = By.XPath("//span[contains(text(),'N450 WiFi Router')]");
        public By buyingOptionsButton = By.XPath("//a[contains(text(),'See All Buying Options')]");
        public By addCartButton = By.XPath("//span[@data-action='aod-atc-action']//span [@class = 'a-button-inner']//input[@name = 'submit.addToCart']");
        public By itemAdded = By.XPath("//div[contains(text(),'Added')]");
        private By closeItemButton = By.XPath("//i[@class='a-icon aod-close-button']");
        private By goToCartButton = By.XPath("//a[@id='nav-cart']");
        private By cartItemTitle = By.XPath("//span[@class='a-truncate sc-grid-item-product-title a-size-base-plus']");
        private By cartItemPrice = By.XPath("//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap sc-product-price a-text-bold']");
        private By captchaPage = By.XPath("//h4[contains(text(),'Type the characters you see in this image:')]");


        public AmazonItemPage(IWebDriver driver)
        {
            this.driver = driver;
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
        }

        public void navigateHomePage()
        {
            driver.Navigate().GoToUrl(baseUrl);
            Console.WriteLine("Amazon Web Page is opened");
        }

        public void searchForItem(string item)
        {
            try
            {
                IWebElement searchElement = driver.FindElement(searchBox);
                searchElement.SendKeys(item);
                searchElement.SendKeys(Keys.Enter);
                TestContext.WriteLine("Item has been searched for and entered");
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
           
        }

        public void clickItem()
        {
            try
            {
                driver.FindElement(item).Click();
                TestContext.WriteLine("Item has been clicked");
            }
             catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void clickBuyingOption()
        {
            try
            {
                driver.FindElement(buyingOptionsButton).Click();
                TestContext.WriteLine("Buying Option has been clicked");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void clickAddCartButton()
        {
            try
            {
                driver.FindElement(addCartButton).Click();
                TestContext.WriteLine("Add Item Button has been clicked");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public bool itemAddedDisplayed()
        {
            try
            {
                TestContext.WriteLine("Item has successfully been added");
                return driver.FindElement(itemAdded).Displayed;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void clickCloseItem()
        {
            try
            {
                driver.FindElement(closeItemButton).Click();
                TestContext.WriteLine("Close Item has been clicked");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void clickGoToCartButton()
        {
            try
            {
                driver.FindElement(goToCartButton).Click();
                TestContext.WriteLine("Go Cart has been clicked");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public bool correctItemTitleDisplayed()
        {
            try
            {
                return driver.FindElement(cartItemTitle).Displayed;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public bool correctItemPriceDisplayed()
        {
            try
            {
                return driver.FindElement(cartItemPrice).Displayed;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public bool capchaDisplayed()
        {
            try
            {
                if (driver.FindElement(captchaPage).Displayed)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            
        }
    }
}
